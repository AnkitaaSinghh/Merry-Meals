import React, { Component } from 'react'
import ABCLearning from "../image/ABCLearning.jpg"

class HomeComponent extends Component {
    render() {
const abclearning={
    border: "1px solid #ddd",
    borderRadius: "4px",
    padding: "5px",
    width: "100%",
};
        return(

<div><br></br>


<img  src={ABCLearning} style={abclearning} alt="ABCLearning"/>
<center><br></br>
<h3>WELCOME USER! </h3></center>
<br></br><br></br><br></br>

</div>

        )
        
    
    }
     

    }
export default HomeComponent













