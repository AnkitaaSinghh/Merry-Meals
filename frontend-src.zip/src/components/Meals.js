import React, {useState, useEffect} from 'react';

import Types from './Types';
import Products from './Products';
import Cart from './Cart';
import filterList from './filterList';
import ScrollToTopBtn  from './ScrollToTop';
import './meals.css';




const Meals = () => {

  const [products, setProducts] = useState([]);
  const [selectedTypes, setSelectedTypes] = useState([]);
  const [cart, setCart] = useState([]);
 
  useEffect(() => {
    setProducts(filterList([], null));
    if(JSON.parse(localStorage.getItem("cart"))) {
      setCart(JSON.parse(localStorage.getItem("cart")));
    }
  }, [])

  const setType = (type) => {
    const types = [...selectedTypes];
    
    if(types.includes(type)) {
      const index = types.indexOf(type);
      types.splice(index, 1);
    }
    else {
      types.push(type);
    }
    setSelectedTypes(types);
    setProducts(filterList(types, 'type'));
  }

  const sortProducts = (method) => {
    const array = products;

 
    if(method === "Lowest to Highest") {
        array.sort(function(a, b){
          return a.price-b.price
      })
    }
    else if(method === "Highest to Lowest") {
        array.sort(function(a, b){
          return b.price-a.price
      })
    }
    setProducts(array);
  }

  const addToCart = (item) => {
    const productList = [...cart];
    if(!productList.includes(item)) {
      productList.push(item);
    }
    const index = productList.indexOf(item);
    productList[index].quantity++;
    setCart(productList);
    localStorage.setItem("cart", JSON.stringify(productList));
  }

  const changeQuantity = (item, e) => {
    const productList = [...cart];
    const index = productList.indexOf(item);
    if(e === '+') {
      productList[index].quantity++;
    }
    else {
      if(productList[index].quantity > 1) {
        productList[index].quantity--;
      }
      else {
        productList.splice(index, 1);
      }
    } 
    setCart(productList);
    localStorage.setItem("cart", JSON.stringify(productList));
  }
  
  return (
    <div className="App">
      <Types selectedTypes={selectedTypes} setType={setType} />
      <Products products={products} sortProducts={sortProducts} addToCart={addToCart} />
      <Cart products={cart} changeQuantity={changeQuantity} />
      <ScrollToTopBtn />


    </div>
  );
}

export default Meals;
