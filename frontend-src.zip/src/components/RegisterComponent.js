import React, { Component } from 'react'
import AuthService from "../services/auth.service";
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormLabel from '@mui/material/FormLabel';
import mail from "../image/mail.png"


class RegisterComponent extends Component {

    constructor(props) {


        
        super(props)

        this.state = {
            // step 2
            username:'',
            password: '',
            name: '',
            email: '',
            fname:'',
            lname:'',
            mobile:'',
            cid:'',
            eid:'',
            orgname:'',
            add:'',
            city:'',
            state:'',
            zip:'',
            time:'',
          part_vol:'',
          volunteer:'',

          volToggle:'',
          toggle:'',
          
          emailerr:'',
          ziperr:'',
          usernameerr:'',
          passworderr:'',
          part_volerr:'',

        }




        this.changeUserNameHandler = this.changeUserNameHandler.bind(this);
       

        this.changePasswordHandler = this.changePasswordHandler.bind(this);
        this.changeEmailHandler = this.changeEmailHandler.bind(this);
     
        this.changeOrgNameHandler = this.changeOrgNameHandler.bind(this);
        this.changeMobileHandler = this.changeMobileHandler.bind(this);
        this.changeAddressHandler = this.changeAddressHandler.bind(this);
        this.changeCityHandler = this.changeCityHandler.bind(this);
        this.changeZipHandler = this.changeZipHandler.bind(this);
        this.changeStateHandler = this.changeStateHandler.bind(this);
        this.changeCidHandler = this.changeCidHandler.bind(this);
        this.changeEidHandler = this.changeEidHandler.bind(this);
        this.changeFnameHandler = this.changeFnameHandler.bind(this);
        this.changeLnameHandler = this.changeLnameHandler.bind(this);
        this.changePart_VolHandler = this.changePart_VolHandler.bind(this);
        this.changeTimeHandler = this.changeTimeHandler.bind(this);
        this.changeVolunteerHandler = this.changeVolunteerHandler.bind(this);

        this.registerUser = this.registerUser.bind(this);
    }


    registerUser = (e) => {
        e.preventDefault();
        if (this.state.part_vol===''){
            this.setState({part_volerr:'Please Select one type of User!'})
            return
        }
        if (this.state.zip===''){
            this.setState({ziperr:'Please Enter Your Zip Code!'})
            return
        }
        if (this.state.email===''){
            this.setState({emailerr:'Please Enter Your Email Id!'})
            return
        }
        if (this.state.username===''){
            this.setState({usernameerr:'Please Enter Your Username Id!'})
            return
        }
        if (this.state.password===''){
            this.setState({passworderr:'Please Enter Your Password!'})
            return
        }
        let user = {username: this.state.username, password: this.state.password, email: this.state.email,fname: this.state.fname,cid: this.state.cid,eid: this.state.eid,address: this.state.address,lname: this.state.lname,mobile: this.state.mobile,city: this.state.city,state: this.state.state,zip: this.state.zip,part_vol: this.state.part_vol,orgname: this.state.orgname,  time: this.state.time, volunteer:this.state.volunteer};       
         console.log('user => ' + JSON.stringify(user));

        // step 5
          //  CarService.saveUser(user).then(res =>{
                AuthService.register(user).then(res =>{
                console.log("Response is "+JSON.stringify(res) + res.status);
                console.log("Response Stauts is "+ res.status);
                if (res.status==200){
                    this.props.history.push('/login');
                }else{
                    this.props.history.push('/register');
                }
            });
        
    }
    
    
    changeOrgNameHandler= (event) => {
        this.setState({orgname: event.target.value});
    }
    changeUserNameHandler= (event) => {
        this.setState({username: event.target.value, usernameerr:''});
    }

    changePasswordHandler= (event) => {
        this.setState({password: event.target.value, passworderr:''});
    }

    changeEmailHandler= (event) => {
        this.setState({email: event.target.value, emailerr:''});
    }

    changeEidHandler= (event) => {
        this.setState({eid: event.target.value});
    }

    changeCidHandler= (event) => {
        this.setState({cid: event.target.value});
    }

    changeFnameHandler= (event) => {
        this.setState({fname: event.target.value});
    }
    changeLnameHandler= (event) => {
        this.setState({lname: event.target.value});
    }
    changeMobileHandler= (event) => {
        this.setState({mobile: event.target.value});
    }
    changeCityHandler= (event) => {
        this.setState({city: event.target.value});
    }
    changeStateHandler= (event) => {
        this.setState({state: event.target.value});
    }
    changeZipHandler= (event) => {
        this.setState({zip: event.target.value,ziperr:''});
    }
    changeAddressHandler= (event) => {
        this.setState({address: event.target.value});
    }
    changePart_VolHandler= (event) => {
        this.setState({part_vol: event.target.value, part_volerr:''});
    }
    changeTimeHandler= (event) => {
        this.setState({time: event.target.value});
    }

    changeVolunteerHandler= (event) => {
        this.setState({volunteer: event.target.value});
    }
 
    cancel(){
        this.props.history.push('/');
    }

    render() {
        return (
            <div>
                <br></br>
                   <div className = "container">
                        <div className = "row">
                            <div className = "card col-md-6 offset-md-3 offset-md-3" style={{width: "70%",height:"100%"}}>
                                    <h1> Register New User </h1>
                                <div className = "card-body" style={{width: "80%"}}>
                                <form noValidate autoComplete="off">

                                <div className = "form-group">
                                <RadioGroup   className = "col-md-6 offset-md-3 offset-md-3" row    aria-labelledby="demo-row-radio-buttons-group-label"      name="row-radio-buttons-group"  >

                                <FormLabel id="demo-row-radio-buttons-group-label"  name="part_vol" value={this.state.part_vol} onChange={this.changePart_VolHandler}><strong>You Are:</strong>
    
        <FormControlLabel value="partner"  onClick={()=>{this.setState({toggle:'part'})}}   control={<Radio />} label="Partner" style={{marginLeft:"30px"}}/>

        <FormControlLabel value="volunteer" onClick={()=>{this.setState({toggle:'vol'})}}    control={<Radio />} label="Volunteer" />
        </FormLabel>
        {this.state.part_volerr ? <span style={{color:"red", textAlign:"center"}}> {this.state.part_volerr}</span>:null}

        
      </RadioGroup>

 
                                </div>
                                        <br></br>
                                        
                                { this.state.toggle==='part'?(<div>
                                    
                                    <div className = "form-group">
                                            <input placeholder="Enter Your Organization Name" name="orgname" className="form-control" 
                                                value={this.state.orgname} onChange={this.changeOrgNameHandler}/>
                                        </div>
                                        <br></br>
                                        
                                        <div className = "row">
                                   <div class="col">                                                   <input placeholder="Enter Your Company ID" name="cid" className="form-control" 
                                                value={this.state.cid} onChange={this.changeCidHandler}/>
                                        </div>
                                      

                                        <div class="col"> 
                                            <input placeholder="Enter Your Employee ID" name="eid" className="form-control" 
                                                value={this.state.eid} onChange={this.changeEidHandler}/>
                                        </div></div>
                                        </div>):this.state.toggle==='vol'?(<div>
                                           
                                            <div className = "form-group">
                                <RadioGroup    row    aria-labelledby="demo-row-radio-buttons-group-label"      name="row-radio-buttons-group"  >

                                <FormLabel id="demo-row-radio-buttons-group-label"  name="volunteer" value={this.state.volunteer} onChange={this.changeVolunteerHandler}>I want to Volunteer In:
    
        <FormControlLabel value="kitchen"  onClick={()=>{this.setState({volToggle:'kitchen'})}}   control={<Radio />} label="Kitchen" style={{marginLeft:"30px"}}/>

        <FormControlLabel value="delivery" onClick={()=>{this.setState({volToggle:'delivery'})}}    control={<Radio />} label="Delivery" />

        { this.state.volToggle==='kitchen'?(
    <div>
    <label className="alert alert-success" style={{width: "150%",height:"80%"}}>
		 <img  src={mail} alt="Mail" style={{height:"30px"}}/>		
<strong>       Check Email </strong> when next kitchen shcedule's available!</label>
</div>):this.state.volToggle==='delivery'?(<div>


    <label className="alert alert-success" style={{width: "132%",height:"80%"}}>
    <img  src={mail} alt="Mail" style={{height:"30px"}}/>	
        <strong>       Check Email </strong>for next delivery areas and schedule's available!</label>
</div>):null}

        </FormLabel>
      </RadioGroup>
 
                                </div>
    
    </div>):null}


                                        <br></br>
                                        <div className = "row">
                                   <div class="col">               <input placeholder="Enter Your First Name" name="fname" className="form-control" 
                                                value={this.state.fname} onChange={this.changeFnameHandler}/>
                                        </div>
                                    

                                        <div class="col">                                                          <input placeholder="Enter Your Last Name" name="lname" className="form-control" 
                                                value={this.state.lname} onChange={this.changeLnameHandler}/>
                                        </div>
                                        </div>
                                        <br></br>

                                        <div className = "form-group">
                                            <input placeholder="Enter Your Address" name="add" className="form-control" 
                                                value={this.state.address} onChange={this.changeAddressHandler}/></div>
                                   
                                   <br></br>
                                   <div className = "row">
                                   <div class="col">
                                            <input placeholder="Enter Your City" name="city" className="form-control" 
                                                value={this.state.city} onChange={this.changeCityHandler}/>
                                      </div>

                                      <div class="col">
                                                                         
                                            <input placeholder="Enter Your State" name="state" className="form-control" 
                                                value={this.state.state} onChange={this.changeStateHandler}/>

                                                </div>
                                    
                                                <div class="col">
                                            <input placeholder="Enter Your Zip Code" name="zip" className="form-control" 
                                                value={this.state.zip} onChange={this.changeZipHandler}/>
                                                                              {this.state.ziperr ? <span style={{color:"red"}}> {this.state.ziperr}</span>:null}

</div>
                                        </div>
                                        <br></br>

                                        <div className = "form-group">
                                            <input placeholder="Enter Your Email" name="email" className="form-control" 
                                                value={this.state.email} onChange={this.changeEmailHandler}/>
                              {this.state.emailerr ? <span style={{color:"red"}}> {this.state.emailerr}</span>:null}


                                        </div>
<br></br>

                                        <div className = "form-group">
                                            <input placeholder="Enter Your Phone Number" name="mobile" className="form-control" 
                                                value={this.state.mobile} onChange={this.changeMobileHandler}/>
                                        </div>
                                        <br></br>

                                      
                                       
                                        <div className = "form-group">
                                            <input placeholder="Enter Your Login Name" name="username" className="form-control" 
                                                value={this.state.username} onChange={this.changeUserNameHandler}/>
                                                                              {this.state.usernameerr ? <span style={{color:"red"}}> {this.state.usernameerr}</span>:null}

                                        </div>
                                        <br></br>
                                        <div className = "form-group">
                                            <input placeholder="Enter Your Password" type="password" name="password" className="form-control" 
                                                value={this.state.password} onChange={this.changePasswordHandler}/>
                                                                              {this.state.passworderr ? <span style={{color:"red"}}> {this.state.passworderr}</span>:null}

                                        </div><br></br>

                                        <select name="time" className="form-group btn btn dropdown-toggle card col-md-12 offset-md-12 offset-md-12" style={{width: "100%", height:"100%", alignItems:"left"}}
                                                value={this.state.time} onChange={this.changeTimeHandler}>
        <option value="1Mon"  >I want to Partner/Volunteer for 1 Months</option>
        <option value="3Mon" >I want to Partner/Volunteer for 3 Months</option>
        <option value="6Mon">I want to Partner/Volunteer for 6 Months</option>
        <option value="9Mon">I want to Partner/Volunteer for 9 Months</option>
        <option value="12Mon">I want to Partner/Volunteer for 12 Months</option>
        <option value="Indefinite">I want to Partner/Volunteer for Indefinite</option>

      </select>
    
      <br></br>



                                        <button className="btn btn-success" onClick={this.registerUser}>Save</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                                    </form>



                                    
                                </div>
                            </div></div><br></br>

                   </div>
            </div>
        )
    }
}

export default RegisterComponent