import React, { Component } from 'react'

class PrivacyComponent extends Component {
    render() {
        const mystyle = {
            marginTop:"50px",
            marginBottom:"50px",
            backgroundColor:"#F8F8F8",
            border: "1px solid #ddd",
            borderRadius: "4px",
            padding: "5px",
           };

        return(
<div>
<div class="row">
<div style={mystyle}>

<div className="col-md-12"><br></br>
<center>
<h2>This is the Privacy of our Company</h2></center><br></br>
<p><b>Effective date:</b> January 01, 2021</p>
<p>
Jad Joubran ("us", "we", or "our") operates the tutorial website (the "Service").</p>
<p>
This page informs you of our policies regarding the collection, use, and disclosure of personal data when you use our Service and the choices you have associated with that data. Our Privacy Policy for Jad Joubran is based on the Free Privacy Policy Template Website.
</p><p>
We use your data to provide and improve the Service. By using the Service, you agree to the collection and use of information in accordance with this policy. Unless otherwise defined in this Privacy Policy, terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, accessible from http://localhost:8080/resultsDetails/result"</p>

<br></br><center>
<h2>
Information Collection And Use</h2></center><br></br>
<p>
We collect several different types of information for various purposes to provide and improve our Service to you.
</p>

<br></br><center>
<h2>
Types of Data Collected</h2></center><h4>
Personal Data</h4><p>
While using our Service, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you ("Personal Data"). Personally identifiable information:
</p>
<li>Email address</li>
<li>Github username</li>
<li>Github avatar</li>
<br></br><center>
<h2>
Usage Data</h2></center>
<p>
We may also collect information how the Service is accessed and used ("Usage Data"). This Usage Data may include information such as your browser type, browser version, the pages of our Service that you visit, the time and date of your visit, the time spent on those pages, unique device identifiers and other diagnostic data. However, we anonymize your Internet Protocol address.
</p>

<br></br><center>
<h2>
Tracking & Cookies Data</h2></center>
<p>
We use anonymous cookies to track the activity on our Service and hold certain information.</p>
<p>
Cookies are files with small amount of data which may include an anonymous unique identifier. Cookies are sent to your browser from a website and stored on your device. Tracking technologies also used are beacons, tags, and scripts to collect and track information and to improve and analyze our Service.
</p><p>
    You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Service.
</p>


<br></br><center>
<h2>
Use of Data</h2></center><p>
Jad Joubran uses the collected data for various purposes:</p>

<li>To provide and maintain the Service</li>
<li>To notify you about changes to our Service</li>
<li>To allow you to participate in interactive features of our Service when you choose to do so</li>
<li>To provide customer care and support</li>
<li>To provide analysis or valuable information so that we can improve the Service</li>
<li>To monitor the usage of the Service</li>
<li>To detect, prevent and address technical issues</li>

<br></br><center>
<h2>Disclosure Of Data</h2></center><h4>
Legal Requirements</h4>
<p>
Jad Joubran may disclose your Personal Data in the good faith belief that such action is necessary to:</p>

<li>To comply with a legal obligation</li>
<li>To protect and defend the rights or property of Jad Joubran</li>
<li>To prevent or investigate possible wrongdoing in connection with the Service</li>
<li>To protect the personal safety of users of the Service or the public</li>
<li>To protect against legal liability</li>


<br></br><br></br><br></br>

</div>
</div>
</div></div>
        )
    }

    }
export default PrivacyComponent