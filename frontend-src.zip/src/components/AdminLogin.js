import React, { Component } from "react";
import { Redirect } from "react-router-dom";

class AdminLogin extends Component {
  constructor(props) {
    super(props);
    this.state = {
      islogged: false,
      loginParams: {
        user_id: "",
        user_password: ""
      }
    };
  }
  handleFormChange = event => {
    let loginParamsNew = { ...this.state.loginParams };
    let val = event.target.value;
    loginParamsNew[event.target.name] = val;
    this.setState({
      loginParams: loginParamsNew
    });
  };

  login = event => {
    let user_id = this.state.loginParams.user_id;
    let user_password = this.state.loginParams.user_password;
    if (user_id === "admin" && user_password === "123") {
      this.props.history.push("/adminhome");

      this.setState({
        islogged: true

      });
    }
    event.preventDefault();
  };
  render() {
  
    return (
      <div className="container">
        <form onSubmit={this.login} className="form-signin">
          <div className="row">
            <div className="col">
            <div className = "card col-md-6 offset-md-3 offset-md-3" style={{width: "70%",height:"100%"}}>
            <h1> Admin Login Here </h1><br></br>
            <div className = "card-body"  style={{width: "80%"}}>

            <div className = "form-group">

              <input
                type="text"
                name="user_id" className="form-control" 
                onChange={this.handleFormChange}
                placeholder="Enter Username"
              /></div>
<br></br>

<div className = "form-group">

              <input
                type="password"
                name="user_password" className="form-control" 
                onChange={this.handleFormChange}
                placeholder="Enter Password"
              /></div>

<br></br>
<button className="btn btn-success" style={{backgroundColor  :"#0096FF	", width:"100%"}} type="submit" value="Login">Login</button>

            </div>
          </div></div></div>
        </form>                      <br></br><br></br><br></br>

      </div>
    );
  }
}
export default AdminLogin;
