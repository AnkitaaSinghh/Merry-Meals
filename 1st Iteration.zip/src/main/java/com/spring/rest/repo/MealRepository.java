package com.spring.rest.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.spring.rest.model.Meal;
import com.spring.rest.model.PartVol;

@Repository
public interface MealRepository extends JpaRepository<Meal, Long> {
}