import React from 'react'

const Items = ({selectedItems, setItem}) =>  {

    const items = ['veg', 'non-veg'];

    return (
        <div className="items">
            <h3>Items</h3>
            <div className="item-list">
                {
                    items.map((item, index) => {
                        return (
                            <button 
                                className={ "item" + (selectedItems.includes(item) ? " selected-item" : "")}
                                key={index}
                                onClick={() => setItem(item)}
                            >
                                {item}
                            </button>
                        )
                    })
                }
            </div>
        </div>
    )
}

export default Items;
