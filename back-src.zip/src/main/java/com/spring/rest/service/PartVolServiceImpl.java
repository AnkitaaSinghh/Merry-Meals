package com.spring.rest.service;


import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.spring.rest.model.PartVol;
import com.spring.rest.repo.PartVolRepo;


@Service
@Transactional
public class PartVolServiceImpl implements PartVolService{

	
	@Autowired
	private PartVolRepo repo;
	
	@Override
	public PartVol addUser(PartVol user) {
		return repo.save(user);
	}

	@Override
	public List<PartVol> getAllUser() {
		
		return repo.findAll();
	}

	@Override
	public Optional<PartVol> findUserById(int id) {
	
		return repo.findById(id);
	}

	@Override
	public void deleteUserById(int id) {
		
		repo.deleteById(id);
		
	}

	@Override
	public PartVol getUserById(int id) {
		PartVol user=null;
		Optional<PartVol> oldUser = repo.findById(id);
		if(oldUser.isPresent()) {
			user=oldUser.get();
		}
		return user;
	}



	@Override
	public PartVol login(PartVol user) {
		PartVol repouser = repo.findByUsername(user.getUsername());
        if(repouser == null) {
            throw new RuntimeException("User does not exist.");
        }
        if(!repouser.getPassword().equals(user.getPassword())){
            throw new RuntimeException("Password mismatch.");
        }
		return repouser;
	}
	
}
