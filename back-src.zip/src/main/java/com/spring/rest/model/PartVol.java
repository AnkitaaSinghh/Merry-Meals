package com.spring.rest.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;

@Entity
@EnableAutoConfiguration
public class PartVol {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int user_id;
	private String cid;
	private String email;
	
	private String username;
	
	private String password;
	private String lname;
	private String fname;
	
	private String orgname;
	
	private String mobile;
	private String city;
	private String state;
	private String zip;
	private String part_vol;
	private String address;
	private String time;
	private String volunteer;

	
	
	
	/*@OneToMany(mappedBy="user")
	private Set<Car> cars;
		
	@Fetch(FetchMode.JOIN)
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name="user_id", referencedColumnName="user_id")
	
	*/

	@OneToMany(mappedBy="partvol")

	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	

	
	public String getVolunteer() {
		return volunteer;
	}
	public void setVolunteer(String volunteer) {
		this.volunteer = volunteer;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getOrgname() {
		return orgname;
	}
	public void setOrgname(String orgname) {
		this.orgname = orgname;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	
	public String getPart_vol() {
		return part_vol;
	}
	public void setPart_vol(String part_vol) {
		this.part_vol = part_vol;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	
	
	

public PartVol(int user_id, String cid, String email, String username, String password, String lname, String fname,
			String orgname, String mobile, String city, String state, String zip, String part_vol, String address,
			String time, String volunteer) {
		super();
		this.user_id = user_id;
		this.cid = cid;
		this.email = email;
		this.username = username;
		this.password = password;
		this.lname = lname;
		this.fname = fname;
		this.orgname = orgname;
		this.mobile = mobile;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.part_vol = part_vol;
		this.address = address;
		this.time = time;
		this.volunteer = volunteer;
	}






@Override
public String toString() {
	return "PartVol [user_id=" + user_id + ", cid=" + cid + ", email=" + email + ", username=" + username
			+ ", password=" + password + ", lname=" + lname + ", fname=" + fname + ", orgname=" + orgname + ", mobile="
			+ mobile + ", city=" + city + ", state=" + state + ", zip=" + zip + ", part_vol=" + part_vol + ", address="
			+ address + ", time=" + time + ", volunteer=" + volunteer + "]";
}
public PartVol() {
		
	}
	
	
		
}
