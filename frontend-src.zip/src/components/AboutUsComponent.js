import React, { Component } from 'react'
import jane from "../image/jane.jpg"
import John from "../image/John.jpg"
import mike from "../image/mike.jpg"



class AboutUsComponent extends Component {


    render() {
        

            const column= {
                float: "left",
                width: "33.3%",
                marginBottom: "16px",
                padding: "0 8px",
              };
              
              const card ={
                boxShadow: "0 4px 8px 0 rgba(0, 0, 0, 0.2)",
                margin: "8px",
              };
              
              const aboutSection ={
                  marginTop: "25px",
                padding: "50px",
                backgroundColor: "#474e5d",
                color: "white",
              };
              
              const container ={
                padding: "0 16px",
              };
              
            
              
              const title= {
                color: "grey",
              };
                            
              const button = {
                border: "none",
                outline: "0",
                display: "inline-block",
                padding: "8px",
                color: "white",
                backgroundColor: "#000",
                cursor: "pointer",
                width: "100%",
              };
              
              const buttonHover ={
                backgroundColor: "#555",
              };
              

              return(


            <div><br></br>
            <div style={aboutSection}>
  <h1>About Us Page</h1>
  <p>We Bring Education Yo You</p>
  <p>The foundation of every state is the education of its youth.</p>
  <p>Data is not information, information is not knowledge, knowledge is not understanding, understanding is not wisdom.</p>
</div>
<center><br></br>
<h2>Our Team</h2></center>
<div className="row">
  <div className="column" style={column}>
    <div className="card" style={card}>
      <img  src={jane} alt="Jane" style={{width:"100%", height:"450px"}}/>
      <div className="container" style={container}>
        <h2>Jane Gomez</h2>
        <p className="title" style={title}>CEO & Founder</p>
        <p><i>Children have to be educated, but they have also to be left to educate themselves.</i></p>
        <p>jane@example.com</p>
        <p><button className="button" style={button}>Contact</button></p>
      </div>
    </div>
  </div>

  <div className="column" style={column}>
    <div class="card" style={card}>
      <img src={mike} alt="Mike" style={{width:"100%", height:"450px"}}/>
      <div className="container" style={container}>
        <h2>Marcel Ross</h2>
        <p className="title" style={title}>Head Department</p>
        <p><i>Learning is not attained by chance, it must be sought for with ardor and diligence.</i></p>
        <p>marcel@example.com</p>
        <p><button className="button" style={button}>Contact</button></p>
      </div>
    </div>
  </div>
  
  <div className="column" style={column}>
    <div className="card" style={card}>
      <img src={John} alt="John" style={{width:"100%", height:"450px"}}/>
      <div className="container" style={container}>
        <h2>John Tatum</h2>
        <p className="title" style={title}>Designer</p>
        <p><i>Education is simply the soul of a society as it passes from one generation to another.</i></p>
        <p>john@example.com</p>
        <p><button className="button" style={button}>Contact</button></p>
      </div>
</div></div></div><br></br><br></br>
<br></br></div>
        )
    }
       
}
export default AboutUsComponent