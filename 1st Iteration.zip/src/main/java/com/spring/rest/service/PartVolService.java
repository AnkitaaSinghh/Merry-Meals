package com.spring.rest.service;

import java.util.List;
import java.util.Optional;

import com.spring.rest.model.PartVol;

public interface PartVolService {

	public PartVol addUser(PartVol user);
	public List<PartVol> getAllUser();
	public Optional<PartVol> findUserById(int id);
	public void deleteUserById(int id);
	public PartVol getUserById(int id);
	public PartVol login(PartVol user);
}
