import React, { Component } from 'react';
import AuthService from "../services/auth.service";
import { Switch, Route, Link } from "react-router-dom";
import meals from "../image/meals.png"

class HeaderComponent extends Component {


constructor(props) {
    super(props);
    this.logOut = this.logOut.bind(this);

    this.state = {
      currentUser:false,
    };
  }


componentDidMount() {
    const user = AuthService.getCurrentUser();

    if (user) {
      this.setState({
        currentUser: user,
      });
    }
  }

  logOut() {
    AuthService.logout();
  }


    render() {
      const mystyle = {
       color: "white",
       fontSize:"20px",
       marginTop:"0px",
       marginBottom:"0px",
       fontFamily: "Brush Script MT", 
      
       };
     
       
        return (


            <div>
<nav class="navbar navbar-expand-md bg-dark navbar-dark">
                    <div className="navbar-nav" style={mystyle}>


{this.state.currentUser==false && (
            <li className="nav-item">
                 <a className="nav-link"  href="/homeop" >   <img  src={meals} alt="Meals" style={{width:"100%", height:"70px"}}/></a>
            </li>
        )}
        

        {this.state.currentUser==false && (
            <li className="nav-item">
             <a className="nav-link" href="/adminlogin">Admin Login</a>
            </li>
        )}

 

         {this.state.currentUser==false && (
            <li className="nav-item">
             <a className="nav-link" href="/register">Register</a>
            </li>
        )}
        
        {this.state.currentUser==false && (
            <li className="nav-item">
             <a className="nav-link" href="/login">Login</a>
            </li>
        )}

{this.state.currentUser && (
                 <a className="nav-link"  href="/home"  style={mystyle} >   <img  src={meals} alt="Meals" style={{width:"100%", height:"70px",  marginBottom:"0px"}}/></a>

        )}

        {this.state.currentUser && (
                <li className="nav-item text-right">
                    <a className="nav-link text-right" href="/home"> Welcome {this.state.currentUser.username}</a>
                </li>
        )}
 
              {this.state.currentUser && (
              <li className="nav-item">
                <Link to={"/about"} className="nav-link">
                 About Us
                </Link>
              </li>
            )}
               {this.state.currentUser && (
              <li className="nav-item">
                <Link to={"/todays"} className="nav-link">
                Meals
                </Link>
              </li>
            )}

              {this.state.currentUser && (
              <li className="nav-item">
                <Link to={"/safety"} className="nav-link">
                 Food Safety
                </Link>
              </li>
            )}
              {this.state.currentUser && (
              <li className="nav-item">
                <Link to={"/privacy"} className="nav-link">
                 Terms & Conditions
                </Link>
              </li>
            )}



        {this.state.currentUser && (
                <li className="nav-item text-left">
                    <a href="/login" className="nav-link" onClick={this.logOut}>LogOut</a>
                </li>
        )}
 


                        </div>
            
                    </nav>
            </div>
        )
    }
}

export default HeaderComponent


