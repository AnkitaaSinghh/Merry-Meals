import React, { Component } from 'react'
import './meal2.css';
import meal from "../image/meal.png"
import mem from "../image/mem.png"
import partner from "../image/partner.png"



class AdminHome extends Component {
    render() {
const abclearning={
    // border: "1px solid #ddd",
    // borderRadius: "4px",
    // padding: "5px",
    // width: "100%",
};
        return(

<div style={{height:"800px"}}><br></br>

<div class="row">
  <div class="column">
  <a href="Meals">
 <img src={partner} alt="  Partner"style={{height:"200%", width: "100%", border:"2px solid #ddd", borderRadius:"4px"}}/></a>
  
  </div>
  <div class="column">
  <a href="Meals">

  <img src={mem} alt="Member" style={{height:"200%", width: "100%", border:"2px solid #ddd", borderRadius:"4px"}}/></a>

  </div>
  <div class="column">
  <a href="adminmeal">

  <img src={meal} alt="Meal"style={{height:"200%", width: "100%", border:"2px solid #ddd", borderRadius:"4px"}}/></a>

  
  </div>
</div>

</div>

        )
        
    
    }
     

    }
export default AdminHome













