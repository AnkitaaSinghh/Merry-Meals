package com.spring.rest.security;

import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.spring.rest.model.PartVol;
import com.spring.rest.repo.PartVolRepo;

@Component
public class PartVolDetailsServiceImpl implements UserDetailsService {

	@Autowired
	private PartVolRepo userRepo;

	public PartVolDetailsServiceImpl(PartVolRepo userRepository) {
		this.userRepo = userRepository;
	}
//
//@Autowired
//	private MemCgRepo userRepo;
//
//	public MemCgDetailsServiceImpl(MemCgRepo userRepository) {
//		this.userRepo = userRepository;
//	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		PartVol user = userRepo.findByUsername(username);

		if (user == null) {
			throw new UsernameNotFoundException(username);
		}

		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
				Collections.emptyList());
	}




}
