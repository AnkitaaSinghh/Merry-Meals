package com.spring.rest.service;

import java.util.List;
import java.util.Optional;

import com.spring.rest.model.Meal;


public interface MealService {

    List<Meal> findAll();

    Optional<Meal> findById(Long id);

    Meal save(Meal meal);

    void delete(Meal meal);
}