import React, { Component } from 'react'
import AuthService from "../services/auth.service";

class LoginComponent extends Component {

    constructor(props) {
        super(props)

        this.state = {
            // step 2
            username:'',
            password: '',
            errorMessage:'',
            usernameerr:'',
            passworderr:''
        }
        this.changeUserNameHandler = this.changeUserNameHandler.bind(this);
        this.changePasswordHandler = this.changePasswordHandler.bind(this);
       
        this.loginUser = this.loginUser.bind(this);
    }


    loginUser = (e) => {
        e.preventDefault();
        if (this.state.username===''){
            this.setState({usernameerr:'Please Enter Your Username Id!'})
            return
        }
        if (this.state.password===''){
            this.setState({passworderr:'Please Enter Your Password!'})
            return
        }
        let user = {username: this.state.username, password: this.state.password};
        console.log('loginuser => ' + JSON.stringify(user));


        AuthService.login(user).then(() => {
          this.props.history.push("/home");
          window.location.reload();
        },
        error => {
          const resMessage =
            (error.response &&
              error.response.data &&
              error.response.data.message) ||
            error.message ||
            error.toString();

          this.setState({
            errorMessage: resMessage
          });
        }
      );

        
    }
    
    changeUserNameHandler= (event) => {
        this.setState({username: event.target.value, usernameerr:''});
    }

    changePasswordHandler= (event) => {
        this.setState({password: event.target.value, passworderr:''});
    }

    cancel(){
        this.props.history.push('/');
    }

    render() {


        
        return (
            <div>
                <br></br><br></br>
                   <div className = "container">
                        <div className = "row">
                        <div className = "card col-md-6 offset-md-3 offset-md-3" style={{width: "70%",height:"100%"}}>
                                    <h1> Login Here </h1>
                                <div className = "card-body"  style={{width: "80%"}}>
                                 {this.state.errorMessage && <div className="alert alert-danger" role="alert"> { this.state.errorMessage } </div> }
                                 <form noValidate autoComplete="off">

                                        <div className = "form-group">
                                            <input placeholder="Enter Your Login Name" name="username" className="form-control" 
                                                value={this.state.username} onChange={this.changeUserNameHandler} />
                                                                                                                              {this.state.usernameerr ? <span style={{color:"red"}}> {this.state.usernameerr}</span>:null}

                                        </div><br></br>
                                        <div className = "form-group">
                                            <input placeholder="Enter Your Password" type="password" name="password" className="form-control" 
                                                value={this.state.password} onChange={this.changePasswordHandler}/>
                                                                                                                              {this.state.passworderr ? <span style={{color:"red"}}> {this.state.passworderr}</span>:null}

                                        </div>
                                        <br></br>

                                        <button className="btn btn-success" onClick={this.loginUser}>Login</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                      <br></br><br></br><br></br>
                   </div>
            </div>
        )
    }
}

export default LoginComponent