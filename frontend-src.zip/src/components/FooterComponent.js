import React, { Component } from 'react'

class FooterComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
                 
        }
    }

    render() {
        const mystyle = {
           position: "relative",
            left: "0",
            bottom: "0",
            width: "100%",
            backgroundColor: "#181818",
            color: "white",
          };
        return (
           
            <div style={mystyle}><center><br></br>
                <footer className = "footer" >
                    <span className="text-muted">All Rights Reserved 2022 </span>
                </footer><br></br></center>
            </div>
        )
    }
}

export default FooterComponent