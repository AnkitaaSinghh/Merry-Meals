package com.spring.rest;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.spring.rest.service.PartVolService;

@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
class ABCLearnCenterApplicationTests {
    @Autowired
    private PartVolService userService;
 
    @Test
    void contextLoads() {
    }
//    @Test
//    void userCount() { 
//        // Check user count
//        int  totalUser=userService.getAllUser().size();
//        assertEquals(5, totalUser, " Match Total user" );
//        }
}