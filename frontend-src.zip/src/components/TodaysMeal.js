import React, { Component } from 'react'
import './meal2.css';

class TodaysMeal extends Component {
    render() {
const abclearning={
    // border: "1px solid #ddd",
    // borderRadius: "4px",
    // padding: "5px",
    // width: "100%",
};
        return(

<div><br></br><img src="https://img.taste.com.au/n7e8yiT2/taste/2016/11/greek-style-lamb-shanks-with-lemon-and-fetta-104613-1.jpeg"  style={{width:"100%"}} alt="todays meal" />


<div id="arrowAnim">
<a href="Meals" style={{fontSize: "26px"}}>CHECK OUT THIS WEEK'S MEAL FOR YOU!

  <div class="arrowSliding">
    <div class="arrow"></div>
  </div>
  <div class="arrowSliding delay1">
    <div class="arrow"></div>
  </div>
  <div class="arrowSliding delay2">
    <div class="arrow"></div>
  </div>
  <div class="arrowSliding delay3">
    <div class="arrow"></div>
  </div></a>
</div>
</div>

        )
        
    
    }
     

    }
export default TodaysMeal













