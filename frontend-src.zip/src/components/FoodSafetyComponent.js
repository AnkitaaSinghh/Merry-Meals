import React, { Component } from 'react'


class FoodSafetyComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
          name: '',
          email: '',
          message: ''
        }
      }
      resetForm(){
        this.setState({name: '', email: '', message: ''})
      }
    render() {
        const mystyle = {
            marginTop: "20px",
            marginBottom: "20px",
          
           };
           const style = {
            marginTop: "35px",
            marginBottom: "40px",
            
           };
        return(
          <div className="App" style={mystyle}><br></br><br></br>
        <h2>  CONTACT US</h2><br></br>

                                      <div className = "card col-lg-12 ">
            <form id="contact-form" style={style}>
              <div className="form-group">
                <label htmlFor="name">Name</label>
                <input type="text" className="form-control" placeholder="Your Name" onChange={this.onNameChange.bind(this)} />
              </div>
              <div className="form-group">
                <label htmlFor="exampleInputEmail1">Email address</label>
                <input type="email" className="form-control" aria-describedby="emailHelp" placeholder="user.name@gmail.com" onChange={this.onEmailChange.bind(this)} />
              </div>
              <div className="form-group">
                <label htmlFor="message">Message</label>
                <textarea className="form-control" rows="5" placeholder="Write your message" onChange={this.onMessageChange.bind(this)} />
              </div>
              <button type="submit" className="btn btn-primary">Submit</button>
            </form></div><br></br><br></br><br></br>
          </div>
        );
      }
    
      onNameChange(event) {
        this.setState({name: event.target.value})
      }
    
      onEmailChange(event) {
        this.setState({email: event.target.value})
      }
    
      onMessageChange(event) {
        this.setState({message: event.target.value})
      }
    
      handleSubmit(event) {
      }
    }


    

export default FoodSafetyComponent