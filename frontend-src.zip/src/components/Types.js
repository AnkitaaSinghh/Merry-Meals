import React from 'react'
import Check from "../image/check.png"

const Types = ({selectedTypes, setType}) =>  {

    const types = ['Diabetic', 'Heart-Friendly','Gluten-free', 'Renal-Friendly', 'Lower-Sodium', 'Pureed', 'Cancer-Support'];

    return (
        <div className="types">
            <h3>Types</h3>
            <div className="type-list">
                {
                    types.map((type, index) => {
                        return (
                            <button 
                                className={ "type" + (selectedTypes.includes(type) ? " selected-type" : "")}
                                key={index}
                                onClick={() => setType(type)}
                            >
                                {type}
                            </button>
                        )
                    })
                }
            </div><br></br>
<div className='prepcard'>
                   <h4>How We Prepare Your Meal?</h4>
<p style={{fontSize:"18px"}}>
<br></br>
<img  src={Check} alt="Check" style={{width:"30px", height:"30px", marginRight:"10px"}}/>               
       In A Well Sanitized Kitchen
                    </p> 


                    <p style={{fontSize:"18px"}}>
                    <img  src={Check} alt="Check" style={{width:"30px", height:"30px", marginRight:"10px"}}/>               
                        Cook's Hand Washed
                    </p> 

                    <p style={{fontSize:"18px"}}>
                    <img  src={Check} alt="Check" style={{width:"30px", height:"30px", marginRight:"10px"}}/>               
                      Daily Temp Check
                    </p> 

                    <p style={{fontSize:"18px"}}>
                    <img  src={Check} alt="Check" style={{width:"30px", height:"30px", marginRight:"10px"}}/>               
                   Fresh Ingredients
                    </p> 

                    <p style={{fontSize:"18px"}}>
                    <img  src={Check} alt="Check" style={{width:"30px", height:"30px", marginRight:"10px"}}/>               
                  USDA‘s ChooseMyPlate Dietary Guidelines
                    </p> 

                    <p style={{fontSize:"18px"}}>
                    <img  src={Check} alt="Check" style={{width:"30px", height:"30px", marginRight:"10px"}}/>               
                    Meal Preferences
                    </p> 
                    <p style={{fontSize:"18px"}}>
                    <img  src={Check} alt="Check" style={{width:"30px", height:"30px", marginRight:"10px"}}/>               
                    All Meals are low in fat, low in saturated fat, and low in cholesterol                    </p> 
</div>

        </div>
    )
}

export default Types;
