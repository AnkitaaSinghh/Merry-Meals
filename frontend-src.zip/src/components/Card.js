import React from 'react'
import cart from "../image/cart.png"


const Card = ({data, addToCart}) => {
    return (
        <div className="card">
            <img src={data.url} className="card-image" alt="product" title={data.title} />
            <h4 className="card-title">{data.title}</h4>
            <p className="price"  style={{fontSize:"16px"}}> <b>Preferred To:</b> <span> {data.prefer}</span></p>
          <p className="price"  style={{fontSize:"17px"}}><b>Specialized For:</b> <span> {data.type}</span></p>
           <p className="price"  style={{fontSize:"14px"}}><span>"{data.desc}"</span></p>

            <button className="add-to-cart" onClick={() => addToCart(data) }>                     
            Add to cart<img src={cart} alt="cart" style={{height:"25px"}} /></button>
        </div>
    )
}

export default Card;
