import axios from "axios";

const API_URL = "http://localhost:8080/login";

class AuthService {
  login(user) {
    return axios.post(API_URL,user)
                .then(response => {
                  console.log("In Service "+ JSON.stringify(response.data.username));
                  if (response.data.accessToken) {
                    localStorage.setItem("user", JSON.stringify(response.data));
                  }
                  return response.data;
                });
  }

  logout() {
    localStorage.removeItem("user");
  }

  register(user) {
    console.log("Register New User");
    return axios.post("http://localhost:8080/userDetails/user" ,user);
  }

  getCurrentUser() {
    return JSON.parse(localStorage.getItem('user'));;
  }
}

export default new AuthService();
