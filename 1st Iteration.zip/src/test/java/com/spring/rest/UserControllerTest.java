package com.spring.rest;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import com.spring.rest.controller.PartVolController;
import com.spring.rest.model.PartVol;
import com.spring.rest.repo.PartVolRepo;
import com.spring.rest.service.PartVolService;

class UserControllerTest {

	
	
	
	@Autowired
	private PartVolService userService;
	
	
	@Test
	void test() {
		//fail("Not yet implemented");
	}
	
	@InjectMocks
    private PartVolController userController;

    @Mock
    private PartVolRepo userRepository;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

   

}
