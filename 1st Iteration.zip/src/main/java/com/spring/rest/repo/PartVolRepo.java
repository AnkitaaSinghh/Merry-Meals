package com.spring.rest.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.rest.model.PartVol;

public interface PartVolRepo extends JpaRepository<PartVol, Integer>{

	PartVol findByUsername(String username);

}
