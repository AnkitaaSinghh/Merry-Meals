import React from 'react';
import './App.css';

import "bootstrap/dist/css/bootstrap.min.css";
import {BrowserRouter as Router} from 'react-router-dom';
import HeaderComponent from './components/HeaderComponent';
import FooterComponent from './components/FooterComponent';
import RegisterComponent from './components/RegisterComponent';
import HomeComponent from './components/HomeComponent';
import FoodSafetyComponent from './components/FoodSafetyComponent'
import AboutUsComponent from './components/AboutUsComponent';
import PrivacyComponent from './components/PrivacyComponents'
import Types from './components/Types';
import Products from './components/Products';
import Cart from './components/Cart';
import filterList from './components/filterList'
import ScrollToTopBtn from "./components/ScrollToTop";
import Meals  from './components/Meals';
import AdminLogin from './components/AdminLogin';
import AdminHome from './components/AdminHome';
import AdminMeal from './components/AdminMeal';
import AdminPartVol from './components/AdminPartVol'
import TodaysMeal from './components/TodaysMeal'




import { Switch, Route, Link } from "react-router-dom";

import LoginComponent from './components/LoginComponent';

function App() {
   
  return (
    <div>
        <Router>
              <HeaderComponent />
                <div className="container">
                    <Switch> 


                          <Route path = "/" exact component = {LoginComponent}></Route>
                          <Route path = "/register" component = {RegisterComponent}></Route>
                          <Route path = "/login" component = {LoginComponent}></Route>
                          <Route path = "/home" component = {HomeComponent}></Route>

                          <Route path = "/safety" component = {FoodSafetyComponent}></Route>
                          <Route path = "/about" component = {AboutUsComponent}></Route>
                          <Route path = "/privacy" component = {PrivacyComponent}></Route>
                          <Route path = "/Types" component = {Types}></Route>
                          <Route path = "/Products" component = {Products}></Route>
                          <Route path = "/Cart" component = {Cart}></Route>
                          <Route path = "/filterList" component = {filterList}></Route>
                          <Route path = "/ScrollToTopBtn" component = {ScrollToTopBtn}></Route>
                          <Route path = "/Meals" component = {Meals}></Route>

                          <Route path = "/adminlogin" component = {AdminLogin}></Route>
                          <Route path = "/adminmeal" component = {AdminMeal}></Route>
                        
                          <Route path = "/adminhome" component = {AdminHome}></Route>

                          <Route path = "/adminpartvol" component = {AdminPartVol}></Route>
                          
                          <Route path = "/todays" component = {TodaysMeal}></Route>


                          </Switch>
                </div>
              <FooterComponent />
        </Router>
    </div>
  );
}
export default App;